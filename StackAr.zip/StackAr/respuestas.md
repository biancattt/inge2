# Taller #1 - Mutation Analysis

## Instrucciones
Completar este documento con las respuestas correspondientes a los ejercicios planteados en el enunciado del taller.

---

## Ejercicio 1: Resultados de generación de mutantes

1. ¿Cuántos mutantes se generaron en total?
   - Respuesta: 69 mutantes

2. ¿Qué operador de mutación generó más mutantes? ¿Cuántos y por qué?
   - Respuesta: TrueConditionalsMutator y FalseConditionalsMutator generaron 10 mutantes cada uno. Esto ocurrió porque en el archivo StackAr.java hay 10 ifs, y siempre se genera el mutante, ya que nunca hay un caso en que el if tenga la condición 
   - como true o false directamente.

3. ¿Qué operador de mutación generó menos mutantes? ¿Cuántos y por qué?
   - Respuesta:
     EmptyReturnsMutator: Genero 3 mutantes. porque hay 2 métodos que retornan enteros y 1 método qeu retorna un string por lo que el EmptyReturnsMutator generó 3 mutantes.
   - IncrementsMutator: Generó 3 mutantes, porque hay solo 3 lineas que incrementan o decrementan una variable local. 
   - NullReturnsMutator: Generó 3 mutantes porque solo hay 3 funciones que devuelven tipos de datos no primitivos: top y pop devuelven Object y toString devuelve un string.
   - ConditionalsBoundaryMutator: Generó 3 mutantes porque solo hay 3 operadores de comparación. (<=, <, >)
   - NegateConditionsMutator: Generó 3 mutantes porque hay 3 condiciones que se pueden reemplazar por sus opuestos.
---

## Ejercicio 2: Evaluación de test suites

1. ¿Cuántos mutantes vivos y muertos encontraron cada uno de los test suites?
   - **StackTests1**:
     - Mutantes vivos: 52
     - Mutantes muertos: 17
   - **StackTests2**:
     - Mutantes vivos: 34
     - Mutantes muertos: 35

2. ¿Cuál es el mutation score de cada test suite?
   - **StackTests1**: 24%
   - **StackTests2**: 50%

---

## Ejercicio 3: Mejora del test suite

1. ¿Cuál es el mutation score logrado para los tests de StackTests3?
   - Respuesta: 95%

2. ¿Cuántos mutantes vivos y muertos encontraron?
   - Mutantes vivos: 3. 
   - Mutantes muertos: 66.

3. Comente cuáles son todos los mutantes vivos que quedaron y por qué son equivalentes al programa original (si no lo fueran, todavía es posible mejorar el mutation score).
   - Respuesta:
   - 3701 es equivalente porque no hay un stack tal que al compararlo con si mismo tenga alguno de sus atributos distintos, entonces termina devolviendo true por mas que no entre en la línea this == obj.
   - 9161 es equivalente porque usa la función top() que ya chequea que no este vacío el stack, entonces no importa si no entra al primer if porque igualemente va a entrar en el if de top y tirar la excepción. 
   - 6259 es equivalente porque multiplicar o dividir por 1 un entero es indistinto. 

4. ¿Cuál es el instruction coverage promedio que lograron para las clases mutadas?
   - Respuesta: 61%

5. ¿Cuál es el peor instruction coverage que lograron para una clase mutada? ¿Por qué creen que sucede esto?
   - Respuesta: 4%. Esto ocurre porque al invocar el constructor de instancia salta la excepción antes de que se pueda correr cualquier instrucción de la clase, entonces con este mutante no se cubre ninguna instrucción que no sea la de los constructores de instancia.
