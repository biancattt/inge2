package org.autotest;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class StackTests3 extends MutationAnalysisRunner {
    @Override
    protected boolean useVerboseMode() {
        return false;
    }

    // Tests de StackTests2.java
    public void testSizeIncreasesByOne() throws Exception {
        Stack stack = createStack();
        assertEquals(0, stack.size());
        stack.push(42);
        assertEquals(1, stack.size());
    }

    public void testDefaultConstructor() throws Exception {
        Stack stack = createStack();
        assertTrue(stack.isEmpty());
    }

    public void testConstructorWithSpecifiedCapacity() throws Exception {
        Stack stack = createStack(5);
    }

    public void testConstructorWithNegativeCapacity() {
        assertThrows(IllegalArgumentException.class, () -> {
            Stack stack = createStack(-1);
        });
    }

    public void testIsEmptyMethod() throws Exception {
        Stack stack = createStack();
        assertTrue(stack.isEmpty());
        stack.push(42);
        assertFalse(stack.isEmpty());
        stack.pop();
        assertTrue(stack.isEmpty());
    }

    public void testIsFullMethod() throws Exception {
        Stack stack = createStack(1);
        assertFalse(stack.isFull());
        stack.push(42);
        assertTrue(stack.isFull());
        stack.pop();
        assertFalse(stack.isFull());
    }

    public void testToStringMethod() throws Exception {
        Stack stack = createStack(2);
        assertEquals("[]", stack.toString());
        stack.push(42);
        assertEquals("[42]", stack.toString());
        stack.push(43);
        assertEquals("[42,43]", stack.toString());
    }

    // COMPLETAR
    public void testStackIsNotNullObject() throws Exception {
        Stack stack = createStack(2);
        assertFalse(stack.equals(null));
    }

    public void testTheSameStackIsEqualToItself() throws Exception {
        Stack stack1 = createStack(2);
        stack1.push(42);
        Stack stack2 = createStack(2);
        stack2.push(42);
        assertTrue(stack1.equals(stack2));
    }

    public void testTwoStacksWithDifferentReadIndexButSamePushedElementsAreDifferent() throws Exception {
        Stack stack1 = createStack(2);
        stack1.push(1);
        stack1.push(2);
        Stack stack2 = createStack(2);
        stack2.push(1);
        stack2.push(2);
        stack2.pop();
        assertFalse(stack1.equals(stack2));
    }

    public void testTwoStacksWithSameReadIndexButDifferentElementsAreDifferent() throws Exception {
        Stack stack1 = createStack(2);
        stack1.push(1);
        stack1.push(3);
        Stack stack2 = createStack(2);
        stack2.push(5);
        stack2.push(2);
        assertFalse(stack1.equals(stack2));
    }

    public void testTwoStacksWithDifferentReadIndexAndDifferentElementsAreDifferent() throws Exception {
        Stack stack1 = createStack();
        try {
            for (int i = 0; i < 10; i++) {
                stack1.push(i);
            }
        } catch (IllegalStateException e) {
            fail();
        }
    }

    public void testAStackIsNotEqualToSomethingThatIsNotAStack() throws Exception {
        Stack stack = createStack(2);
        assertFalse(stack.equals(new ArrayList<Integer>()));
    }

    public void testAStackEqualsItself() throws Exception {
        Stack stack = createStack(2);
        assertTrue(stack.equals(stack));
    }

    public void testCanCreateStackWithZeroCapacity() throws Exception {
        try {
            Stack stack1 = createStack(0);
        } catch (IllegalArgumentException e) {
            fail();
        }
    }

    public void testTopOfEmptyStackThrowsException() throws Exception {
        assertThrows(IllegalStateException.class, () -> {
            Stack stack = createStack();
            stack.top();
        });
    }

    public void testPushToFullStackThrowsException() throws Exception {
        assertThrows(IllegalStateException.class, () -> {
            Stack stack = createStack(1);
            stack.push(1);
            stack.push(2);
        });
    }

    public void testPopFromNotEmptyStackReturnsLastPushedElement() throws Exception {
        Stack stack = createStack(2);
        stack.push(1);
        stack.push(2);
        assertEquals(2, stack.pop());
    }


    public void testTwoDifferentStacksHaveDifferentHashCodes() throws Exception {
        Stack stack1 = createStack(2);
        stack1.push(1);
        stack1.push(2);
        Stack stack2 = createStack(2);
        stack2.push(1);
        stack2.push(3);
        assertNotEquals(stack1.hashCode(), stack2.hashCode());
    }

    public void testStackHashCodeIsCorrect() throws Exception {
        Stack stack = createStack(2);
        stack.push(1);
        stack.push(2);
        int[] nums = new int[2];
        nums[0] = 1;
        nums[1] = 2;
        assertEquals(31 * (31 * (1) + Arrays.hashCode(nums)) + 1, stack.hashCode());
    }

}
